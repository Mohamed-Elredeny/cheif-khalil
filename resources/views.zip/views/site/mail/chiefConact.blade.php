<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    {{-- <meta charset="utf-8"> --}}
</head>
<body>
    <p>from: {{$emaill}}</p>
    <p>name: {{$namee}}</p>      
    <p>{{$messagee}}</p>
                            
</body>
</html>
