@component('mail::message')
# User Message

# username: {{$name}}

# email: {{$email}}

# subject: {{$subject}}

# message: {{$message}}


Thanks,<br>
{{ config('app.name') }}
@endcomponent

